package com.sapiens.social_sapiens

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
