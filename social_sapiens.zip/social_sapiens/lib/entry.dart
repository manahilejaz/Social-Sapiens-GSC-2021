import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:social_sapiens/drawer.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class Entry extends StatefulWidget {
  @override
  _EntryState createState() => _EntryState();
}

class _EntryState extends State<Entry> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF373737),
      appBar: AppBar(
        title: Text('Social Sapiens'),
        centerTitle: true,
        backgroundColor: Colors.black,
        elevation: 3.0,
        actions: <Widget>[
          IconButton(
            icon: Icon(FontAwesomeIcons.home),
            onPressed: (){
              Navigator.pushNamed(context, '/home');
            },
          ),
        ],
      ),
      drawer: MyDrawer(),
      body: ListView(
        children: <Widget>[
          CarouselSlider(
            items: <Widget>[
              Container(
                margin: EdgeInsets.all(4.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: DecorationImage(
                    image: AssetImage('assets/sd1.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(4.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: DecorationImage(
                    image: AssetImage('assets/sd2.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(4.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: DecorationImage(
                    image: AssetImage('assets/sd3.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.all(4.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: DecorationImage(
                    image: AssetImage('assets/sd4.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ],
            options: CarouselOptions(
              height: 185.0,
              aspectRatio: 15/6,
              autoPlayCurve: Curves.ease,
              enableInfiniteScroll: true,
              autoPlayAnimationDuration: Duration(milliseconds: 200),
              enlargeCenterPage: true,
              autoPlay: true,
              viewportFraction: 0.6,
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                "Help The Way It Should Be",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 30.0,
                  letterSpacing: 3.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              Text(
                "Correct platfrom to help someone.\nLigit and authentic cases with images and videos.\nDirect contact to give charity",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 20.0,
                  letterSpacing: 3.0,
                  fontWeight: FontWeight.w300,
                ),
              ),
              SizedBox(
                height: 20.0,
                width: 150.0,
                child: Divider(
                  color: Colors.teal.shade100,
                ),
              ),
            ],
          ),
          Card(
            margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
            color: Colors.black87,
            child: ListTile(
              leading:  Icon(
                FontAwesomeIcons.home,
                color: Colors.white,
              ),
              title: Text(
                "Social Sapiens Home",
                style: TextStyle(
                  color: Colors.white,
                  letterSpacing: 2.0,
                  fontSize: 19.0,
                ),
              ),
              onTap: (){
                Navigator.pushNamed(context, '/home');
              },
            ),
          ),
          Card(
            margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
            color: Colors.black87,
            child: ListTile(
              leading:  Icon(
                FontAwesomeIcons.ticketAlt,
                color: Colors.white,
              ),
              title: Text(
                "All Cases",
                style: TextStyle(
                  color: Colors.white,
                  letterSpacing: 2.0,
                  fontSize: 19.0,
                ),
              ),
              onTap: (){
                Navigator.pushNamed(context, '/cases');
              },
            ),
          ),
          Card(
            margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
            color: Colors.black87,
            child: ListTile(
              leading:  Icon(
                FontAwesomeIcons.peopleArrows,
                color: Colors.white,
              ),
              title: Text(
                "Help",
                style: TextStyle(
                  color: Colors.white,
                  letterSpacing: 2.0,
                  fontSize: 19.0,
                ),
              ),
              onTap: (){
                Navigator.pushNamed(context, '/help');
              },
            ),
          ),
        ],
      ),
    );
  }
}