import 'package:flutter/material.dart';

class MyDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.all(10),
        children: <Widget>[
          SizedBox(height: 50),
          Text('Social Sapiens',
            style: TextStyle(
                fontSize: 30
            ),
          ),
          Divider(
              thickness: 2,
              color: Colors.black
          ),
          SizedBox(height: 35),
          ListTile(
            title: Text('Home'),
            trailing: Icon(Icons.keyboard_arrow_right,),
            contentPadding: EdgeInsets.symmetric(horizontal: 0.0),
            onTap: (){
              Navigator.pushNamed(context,'/home');
            },
          ),
          Divider(),
          ListTile(
            title: Text('All Cases'),
            trailing: Icon(Icons.keyboard_arrow_right,),
            contentPadding: EdgeInsets.symmetric(horizontal: 0.0),
            onTap: (){
              Navigator.pushNamed(context,'/cases');
            },
          ),
          Divider(),
          ListTile(
            title: Text('Help'),
            trailing: Icon(Icons.keyboard_arrow_right,),
            contentPadding: EdgeInsets.symmetric(horizontal: 0.0),
            onTap: (){
              Navigator.pushNamed(context,'/help');
            },
          ),
          Divider(),
        ],
      ),
    );
  }
}

