import 'package:flutter/material.dart';
import 'package:social_sapiens/entry.dart';
import 'package:social_sapiens/screens/cases.dart';
import 'package:social_sapiens/screens/help.dart';
import 'package:social_sapiens/screens/home.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/entry',
      routes: {
        '/entry':(context) =>Entry(),
        '/home': (context) =>Home(),
        '/cases': (context) => Cases(),
        '/help':(context) => Help(),
      },
    );
  }
}