import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';


class Cases extends StatefulWidget {
  @override
  _CasesState createState() => _CasesState();
}

class _CasesState extends State<Cases> {
  @override
  Widget build(BuildContext context) {
    return WebviewScaffold(
      appBar: AppBar(
        title: Text('Cases'),
        backgroundColor: Colors.black,
        centerTitle: true,
      ),
      url: 'http://aftabah771.pythonanywhere.com/all_cases/',
      hidden: true,
    );
  }
}
