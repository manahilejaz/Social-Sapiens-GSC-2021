import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';

class Help extends StatefulWidget {
  @override
  _HelpState createState() => _HelpState();
}

class _HelpState extends State<Help> {
  @override
  Widget build(BuildContext context) {
    return WebviewScaffold(
      appBar: AppBar(
        title: Text('Help'),
        backgroundColor: Colors.black,
        centerTitle: true,
      ),
      url: 'http://aftabah771.pythonanywhere.com/help/',
      hidden: true,
    );
  }
}
